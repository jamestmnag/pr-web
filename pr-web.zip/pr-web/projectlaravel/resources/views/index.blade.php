<!DOCTYPE html>
<html lang="en">
@extends('layouts.app')
@section('content')
<p>
    this is the content.
</p>


@endsection






</body>
</html>