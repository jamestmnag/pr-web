<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('content'); ?>
<p>
    this is the content.
</p>


<?php $__env->stopSection(); ?>






</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\James\Desktop\pr-web\projectlaravel\resources\views/index.blade.php ENDPATH**/ ?>